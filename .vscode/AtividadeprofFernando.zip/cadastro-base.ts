import { EntidadeNome, StatusCadastro } from './enums';

export class CadastroBase {
  id = 0;
  dataCadastro = '';
  status: StatusCadastro = StatusCadastro.ATIVO;

  constructor(init?: Partial<CadastroBase>) {
    Object.assign(this, init);
  }
}

export class HistoricoInativacao {
  id = 0;
  entidade: EntidadeNome = EntidadeNome.DOCENTE;
  entidadeId = 0;
  motivo = '';
  dataAcao = '';
  responsavelId = 0;

  constructor(init?: Partial<HistoricoInativacao>) {
    Object.assign(this, init);
  }
}

export class InativarRequest {
  motivo = '';

  constructor(init?: Partial<InativarRequest>) {
    Object.assign(this, init);
  }
}

export class Pagina<T> {
  content: T[] = [];
  totalElements = 0;
  totalPages = 0;
  number = 0;
  size = 0;

  constructor(init?: Partial<Pagina<T>>) {
    Object.assign(this, init);
  }
}
