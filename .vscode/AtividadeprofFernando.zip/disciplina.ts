import { CadastroBase } from './cadastro-base';
import { Curso } from './curso';
import { TipoEspaco } from './enums';

export class Disciplina extends CadastroBase {
  sigla = '';
  descricao = '';
  cursoId = 0;
  curso?: Curso;
  cargaHoraria = 0;
  tipoEspaco: TipoEspaco = TipoEspaco.SALA_DE_AULA;
  docenteId?: number;
  possuiHistorico = false;

  constructor(init?: Partial<Disciplina>) {
    super();
    Object.assign(this, init);
  }
}
