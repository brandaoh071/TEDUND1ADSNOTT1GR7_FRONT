import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';
import { REGRAS_SOLICITACAO as R, SolicitacaoRequest } from './solicitacao';

export function validarSolicitacao(req: SolicitacaoRequest): string[] {
  const erros: string[] = [];
  const itens = req.itens ?? [];

  if (itens.length < R.MIN_DISCIPLINAS || itens.length > R.MAX_DISCIPLINAS) {
    erros.push(`Selecione entre ${R.MIN_DISCIPLINAS} e ${R.MAX_DISCIPLINAS} disciplinas.`);
  }

  const ids = itens.map(i => i.disciplinaId);
  if (new Set(ids).size !== ids.length) {
    erros.push('Não é permitido repetir a mesma disciplina.');
  }

  const prioridadeInvalida = itens.some(
    i => !Number.isInteger(i.prioridade) || i.prioridade < R.PRIORIDADE_MIN || i.prioridade > R.PRIORIDADE_MAX
  );
  if (prioridadeInvalida) {
    erros.push(`A prioridade deve estar entre ${R.PRIORIDADE_MIN} e ${R.PRIORIDADE_MAX}.`);
  }

  const maximas = itens.filter(i => i.prioridade === R.PRIORIDADE_MAX).length;
  if (maximas > R.MAX_COM_PRIORIDADE_MAXIMA) {
    erros.push(`Apenas ${R.MAX_COM_PRIORIDADE_MAXIMA} disciplinas podem ter prioridade ${R.PRIORIDADE_MAX}.`);
  }

  return erros;
}

export const itensSolicitacaoValidator: ValidatorFn = (control: AbstractControl): ValidationErrors | null => {
  const erros = validarSolicitacao({ itens: control.value ?? [] });
  return erros.length ? { solicitacao: erros } : null;
};
