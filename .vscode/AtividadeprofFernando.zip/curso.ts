import { CadastroBase } from './cadastro-base';
import { CentroAcademico } from './centro-academico';
import { Turno } from './enums';
import { Responsavel } from './ies';

export class Curso extends CadastroBase {
  sigla = '';
  descricao = '';
  centroAcademicoId = 0;
  centroAcademico?: CentroAcademico;
  turnos: Turno[] = [];
  coordenador: Responsavel = new Responsavel();
  possuiHistorico = false;

  constructor(init?: Partial<Curso>) {
    super();
    Object.assign(this, init);
  }
}
