import { CadastroBase } from './cadastro-base';

export class Responsavel {
  nome = '';
  email = '';
  telefone = '';

  constructor(init?: Partial<Responsavel>) {
    Object.assign(this, init);
  }
}

export class ProReitoria {
  id?: number;
  nome = '';
  responsavel: Responsavel = new Responsavel();
  dataNomeacao = '';

  constructor(init?: Partial<ProReitoria>) {
    Object.assign(this, init);
  }
}

export class IES extends CadastroBase {
  sigla = '';
  nome = '';
  emailCentral = '';
  telefoneCentral = '';
  reitor: Responsavel = new Responsavel();
  proReitorias: ProReitoria[] = [];
  possuiHistorico = false;

  constructor(init?: Partial<IES>) {
    super();
    Object.assign(this, init);
  }
}
