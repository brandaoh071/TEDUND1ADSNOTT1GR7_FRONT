import { AcaoAuditoria, EntidadeNome } from './enums';

export class LogAuditoria {
  id = 0;
  usuarioId = 0;
  usuarioLogin = '';
  acao: AcaoAuditoria = AcaoAuditoria.LOGIN;
  entidade?: EntidadeNome;
  entidadeId?: number;
  dataHora = '';
  detalhes = '';

  constructor(init?: Partial<LogAuditoria>) {
    Object.assign(this, init);
  }
}

export class FiltroAuditoria {
  usuarioId?: number;
  acao?: AcaoAuditoria;
  entidade?: EntidadeNome;
  de?: string;
  ate?: string;
  page = 0;
  size = 20;

  constructor(init?: Partial<FiltroAuditoria>) {
    Object.assign(this, init);
  }
}
