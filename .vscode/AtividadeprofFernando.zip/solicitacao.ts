import { DiaSemana, StatusSolicitacao } from './enums';
import { Disciplina } from './disciplina';
import { Discente } from './pessoa';

export const REGRAS_SOLICITACAO = {
  MIN_DISCIPLINAS: 2,
  MAX_DISCIPLINAS: 9,
  PRIORIDADE_MIN: 1,
  PRIORIDADE_MAX: 5,
  MAX_COM_PRIORIDADE_MAXIMA: 2,
} as const;

export type Prioridade = 1 | 2 | 3 | 4 | 5;

export class ItemSolicitacao {
  disciplinaId = 0;
  disciplina?: Disciplina;
  prioridade: Prioridade = 1;

  constructor(init?: Partial<ItemSolicitacao>) {
    Object.assign(this, init);
  }
}

export class OfertaSugerida {
  disciplinaId = 0;
  docenteId = 0;
  diaSemana: DiaSemana = DiaSemana.SEGUNDA;
  horaInicio = '';
  horaFim = '';
  espacoAcademico = '';

  constructor(init?: Partial<OfertaSugerida>) {
    Object.assign(this, init);
  }
}

export class SolicitacaoDisciplina {
  id = 0;
  discenteId = 0;
  discente?: Discente;
  semestre = '';
  itens: ItemSolicitacao[] = [];
  dataSolicitacao = '';
  status: StatusSolicitacao = StatusSolicitacao.AGUARDANDO;
  ofertas: OfertaSugerida[] = [];
  posicaoFila?: number;

  constructor(init?: Partial<SolicitacaoDisciplina>) {
    Object.assign(this, init);
  }
}

export class SolicitacaoRequest {
  itens: Array<Pick<ItemSolicitacao, 'disciplinaId' | 'prioridade'>> = [];

  constructor(init?: Partial<SolicitacaoRequest>) {
    Object.assign(this, init);
  }
}

export class ValidarSolicitacaoRequest {
  aprovar = false;
  ofertas: OfertaSugerida[] = [];

  constructor(init?: Partial<ValidarSolicitacaoRequest>) {
    Object.assign(this, init);
  }
}
