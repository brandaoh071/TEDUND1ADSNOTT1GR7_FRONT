import { CentroAcademico } from './centro-academico';
import { Curso } from './curso';
import { Disciplina } from './disciplina';
import { PerfilAcesso, StatusCadastro } from './enums';
import { IES } from './ies';
import { Discente, Docente } from './pessoa';
import { SolicitacaoDisciplina } from './solicitacao';

export class RelatorioBase {
  emitidoPorId = 0;
  emitidoPorNome = '';
  perfil: PerfilAcesso = PerfilAcesso.ADMINISTRADOR;
  emitidoEm = '';

  constructor(init?: Partial<RelatorioBase>) {
    Object.assign(this, init);
  }
}

export class CentroAcademicoRelatorio extends CentroAcademico {
  cursos: Curso[] = [];

  constructor(init?: Partial<CentroAcademicoRelatorio>) {
    super();
    Object.assign(this, init);
  }
}

export class IESRelatorio extends IES {
  centros: CentroAcademicoRelatorio[] = [];

  constructor(init?: Partial<IESRelatorio>) {
    super();
    Object.assign(this, init);
  }
}

export class RelatorioCadastroGeral extends RelatorioBase {
  instituicoes: IESRelatorio[] = [];

  constructor(init?: Partial<RelatorioCadastroGeral>) {
    super();
    Object.assign(this, init);
  }
}

export class DocentesPorCentro {
  centro: CentroAcademico = new CentroAcademico();
  docentes: Docente[] = [];

  constructor(init?: Partial<DocentesPorCentro>) {
    Object.assign(this, init);
  }
}

export class RelatorioDocentes extends RelatorioBase {
  filtroStatus?: StatusCadastro;
  docentesPorCentro: DocentesPorCentro[] = [];

  constructor(init?: Partial<RelatorioDocentes>) {
    super();
    Object.assign(this, init);
  }
}

export class RelatorioColaborador extends RelatorioBase {
  disciplinas: Disciplina[] = [];
  discentes: Discente[] = [];
  solicitacoes: SolicitacaoDisciplina[] = [];

  constructor(init?: Partial<RelatorioColaborador>) {
    super();
    Object.assign(this, init);
  }
}

export class RelatorioDiscente extends RelatorioBase {
  discente: Discente = new Discente();
  solicitacoes: SolicitacaoDisciplina[] = [];

  constructor(init?: Partial<RelatorioDiscente>) {
    super();
    Object.assign(this, init);
  }
}
