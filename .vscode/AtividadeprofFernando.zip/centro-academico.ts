import { CadastroBase } from './cadastro-base';
import { IES, Responsavel } from './ies';

export class CentroAcademico extends CadastroBase {
  nome = '';
  emailCentral = '';
  telefoneCentral = '';
  coordenador: Responsavel = new Responsavel();
  iesId = 0;
  ies?: IES;
  possuiHistorico = false;

  constructor(init?: Partial<CentroAcademico>) {
    super();
    Object.assign(this, init);
  }
}
