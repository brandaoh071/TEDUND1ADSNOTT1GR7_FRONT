import { CadastroBase } from './cadastro-base';
import { CentroAcademico } from './centro-academico';
import { PerfilAcesso } from './enums';
import { Curso } from './curso';

export class Pessoa extends CadastroBase {
  matricula = '';
  nomeCompleto = '';
  email = '';
  telefone = '';

  constructor(init?: Partial<Pessoa>) {
    super();
    Object.assign(this, init);
  }
}

export class Docente extends Pessoa {
  centroAcademicoId = 0;
  centroAcademico?: CentroAcademico;

  constructor(init?: Partial<Docente>) {
    super();
    Object.assign(this, init);
  }
}

export class Discente extends Pessoa {
  cursoId = 0;
  curso?: Curso;

  constructor(init?: Partial<Discente>) {
    super();
    Object.assign(this, init);
  }
}

export class UsuarioSistema {
  id = 0;
  login = '';
  email = '';
  perfis: PerfilAcesso[] = [];

  constructor(init?: Partial<UsuarioSistema>) {
    Object.assign(this, init);
  }
}

export class LoginRequest {
  login = '';
  senha = '';

  constructor(init?: Partial<LoginRequest>) {
    Object.assign(this, init);
  }
}

export class LoginResponse {
  token = '';
  tipo = 'Bearer';
  expiraEm = '';
  usuario: UsuarioSistema = new UsuarioSistema();

  constructor(init?: Partial<LoginResponse>) {
    Object.assign(this, init);
  }
}
